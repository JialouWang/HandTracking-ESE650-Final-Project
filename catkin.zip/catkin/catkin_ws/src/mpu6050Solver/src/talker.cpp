#include "ros/ros.h"
#include "std_msgs/String.h"

#include <sstream>


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include "I2Cdev.h"
#include "MPU6050_6Axis_MotionApps20.h"
#include <list>

using namespace std;
// class default I2C address is 0x68
// specific I2C addresses may be passed as a parameter here
uint8_t defaultAddr= 0x68;
uint8_t muxAddr1 = 0x70;
uint8_t muxAddr2 = 0x71;
uint8_t regAddr = 0x00;
const uint8_t dataMux[16] = {
	0b00000001,
	0b00000010,
	0b00000100,
	0b00001000,
	0b00010000,
	0b00100000,
	0b01000000,
        0b10000000,
	0b00000001,
        0b00000010,
        0b00000100,
        0b00001000,
        0b00010000,
        0b00100000,
        0b01000000,
        0b10000000
};
const uint8_t dataMuxIdle = 0b00000000;

list<MPU6050_b*> mpuList;
const int16_t offSetData[96] = {
    -452,-1719,1524,-14,29,-44,
    -2282,-337,2548,60,42,-8,
    -1260,-1893,1680,80,28,-59,
    326,-1813,2618,137,142,136,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85,
    -346,-1707,1526,220,76,-85
};


float allData[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
//float allData[1] = {0};
void muxSel(int bid){
    if(bid<=7){
             I2Cdev::writeByte(bid,muxAddr1,regAddr,dataMuxIdle);
             I2Cdev::writeByte(bid,muxAddr2,regAddr,dataMux[bid]);
	 }
    else{
             I2Cdev::writeByte(bid,muxAddr2,regAddr,dataMuxIdle);
             I2Cdev::writeByte(bid,muxAddr1,regAddr,dataMux[bid]);

         }
}
void setup() {

    for(list<MPU6050_b*>::iterator it = mpuList.begin(); it != mpuList.end();it++){
         printf("MPU6050 %d connection\n",(*it)->getBusId());
	 muxSel((*it)->getBusId());
	 (*it)->initialize();

	 printf((*it)->testConnection() ? "MPU6050 %d connection successful\n" : "MPU6050 %d connection failed\n",(*it)->getBusId());
    	(*it)->devStatus = (*it)->dmpInitialize();
   // (*it)->setXAccelOffset(offSetData[(*it)->getBusId()*4]);
   // (*it)->setYAccelOffset(offSetData[(*it)->getBusId()*4]+1);
   // (*it)->setZAccelOffset(offSetData[(*it)->getBusId()*4]+2);
   // (*it)->setXGyroOffset(offSetData[(*it)->getBusId()*4]+3);
   // (*it)->setYGyroOffset(offSetData[(*it)->getBusId()*4]+4);
   // (*it)->setZGyroOffset(offSetData[(*it)->getBusId()*4]+5);

    // make sure it worked (returns 0 if so)
    if ((*it)->devStatus == 0) {
	printf("dmpIs Ready \n");
        (*it)->CalibrateAccel(6);
        (*it)->CalibrateGyro(6);
	printf("Calbration Success \n");
        (*it)->PrintActiveOffsets();

        printf("Enabling DMP...\n");
        (*it)->setDMPEnabled(true);
        (*it)->mpuIntStatus = (*it)->getIntStatus();
        printf("DMP ready!\n");
        (*it)->dmpReady = true;
        // get expected DMP packet size for later comparison
        (*it)->packetSize = (*it)->dmpGetFIFOPacketSize();
    } else {
        // ERROR!
        // 1 = initial memory load failed
        // 2 = DMP configuration updates failed
        // (if it's going to break, usually the code will be 1)
        printf("DMP Initialization failed (code %d)\n", (*it)->devStatus);
    }
    }

}

std_msgs::String loop() {
    std_msgs::String msg;
    msg.data = "";
    for(list<MPU6050_b*>::iterator it = mpuList.begin(); it != mpuList.end();it++){
    if (!(*it)->dmpReady){
	    printf("%d NotReady \n",(*it)->getBusId());
	    return msg;
    }
    muxSel((*it)->getBusId());
    //printf("BUS: %d current FIFOC %d \n", (*it)->getBusId(),(*it)->getFIFOCount());
    int8_t result = (*it)->dmpGetCurrentFIFOPacket((*it)->fifoBuffer);
    //printf("Getting %d %d \n",(*it)->getBusId(),result);
    if (result) {
        (*it)->dmpGetQuaternion(&((*it)->q),(*it)->fifoBuffer);
	(*it)->dmpGetGravity(&((*it)->gravity), &((*it)->q));
        (*it)->dmpGetYawPitchRoll((*it)->ypr, &((*it)->q), &((*it)->gravity));
	allData[(*it)->getBusId()] = (*it)->ypr[2];
       // printf("BUSID: %d ypr  %7.2f %7.2f %7.2f    \n",(*it)->getBusId(), (*it)->ypr[0] * 180/M_PI, (*it)->ypr[1] * 180/M_PI, (*it)->ypr[2] * 180/M_PI);
    }
    if((*it)->getBusId()!=0) msg.data += "|";
    msg.data += to_string(allData[(*it)->getBusId()]);

    }
    //return msg;
    //printf("Bus0: %f Bus1: %f Bus2: %f Bus3: %f Bus4: %f Bus5: %f Bus6: %f Bus7: %f Bus8: %f Bus9: %f Bus10: %f Bus11: %f Bus12: %f \n",allData[0],allData[1],allData[2],allData[3],allData[4],allData[5],allData[6],allData[7],allData[8],allData[9],allData[10],allData[11],allData[12]);
    return msg;
}

int main(int argc, char **argv)
{

  for (int i = 0; i < 13; i++) {
    mpuList.push_back(new MPU6050_b(defaultAddr, i));
  }
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  ros::Rate rate(10);

  int count = 0;
  setup();
  usleep(1000000);
  printf("setupComplete \n");
  std_msgs::String msg;
  while (ros::ok())
  {
    msg = loop();
    if(msg.data != ""){
    chatter_pub.publish(msg);
    ROS_INFO("Msg Published %s \n",msg.data.c_str());
    }
      ros::spinOnce();
    //usleep(100000);
   // ++count;
  }
  while (!mpuList.empty()){
        list<MPU6050_b*>::iterator it = mpuList.begin();
        delete *it;
        mpuList.erase(it);
  }
  printf("FInished Cleaning \n");
  return 0;
}
